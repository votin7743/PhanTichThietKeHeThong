-- PostgreSQL DDL đề xuất. Chưa triển khai backend.
-- Các kiểm tra liên bảng/role/chuyển trạng thái/unique chống lặp UC ghi thuộc service transaction.
BEGIN;
CREATE TABLE "VaiTro" (
  "ma" VARCHAR(64) PRIMARY KEY,
  "ten" VARCHAR(255) NOT NULL
);

CREATE TABLE "TaiKhoan" (
  "id" UUID PRIMARY KEY,
  "hoTen" VARCHAR(255) NOT NULL,
  "email" VARCHAR(255) NOT NULL,
  "dienThoai" VARCHAR(255) NOT NULL,
  "trangThai" VARCHAR(64) NOT NULL,
  "version" INTEGER NOT NULL,
  "passwordHash" TEXT NOT NULL,
  "vaiTroMa" VARCHAR(255) NOT NULL REFERENCES "VaiTro"("ma") ON DELETE RESTRICT,
  UNIQUE ("email")
);

CREATE TABLE "DanhMuc" (
  "id" UUID PRIMARY KEY,
  "ma" VARCHAR(255) NOT NULL,
  "ten" VARCHAR(255) NOT NULL,
  "moTa" TEXT NOT NULL,
  "trangThai" VARCHAR(64) NOT NULL,
  "version" INTEGER NOT NULL,
  UNIQUE ("ma")
);

CREATE TABLE "SanPham" (
  "id" UUID PRIMARY KEY,
  "ma" VARCHAR(255) NOT NULL,
  "ten" VARCHAR(255) NOT NULL,
  "moTa" TEXT NOT NULL,
  "hinhAnh" VARCHAR(255) NOT NULL,
  "gia" DECIMAL(18,2) NOT NULL,
  "tonVatLy" INTEGER NOT NULL,
  "giuCho" INTEGER NOT NULL,
  "trangThai" VARCHAR(64) NOT NULL,
  "version" INTEGER NOT NULL,
  "danhMucId" UUID NOT NULL REFERENCES "DanhMuc"("id") ON DELETE RESTRICT,
  UNIQUE ("ma"),
  CHECK ("gia" >= 0 AND "tonVatLy" >= "giuCho" AND "giuCho" >= 0)
);

CREATE TABLE "KhuyenMai" (
  "id" UUID PRIMARY KEY,
  "ma" VARCHAR(255) NOT NULL,
  "ten" VARCHAR(255) NOT NULL,
  "kieuGiam" VARCHAR(64) NOT NULL,
  "giaTri" DECIMAL(18,2) NOT NULL,
  "batDau" TIMESTAMP WITH TIME ZONE NOT NULL,
  "ketThuc" TIMESTAMP WITH TIME ZONE NOT NULL,
  "trangThai" VARCHAR(64) NOT NULL,
  "version" INTEGER NOT NULL,
  UNIQUE ("ma"),
  CHECK ("batDau" <= "ketThuc"),
  CHECK (("kieuGiam" = 'PHAN_TRAM' AND "giaTri" > 0 AND "giaTri" <= 100) OR ("kieuGiam" = 'SO_TIEN' AND "giaTri" > 0))
);

CREATE TABLE "PhuongThucThanhToan" (
  "id" UUID PRIMARY KEY,
  "ten" VARCHAR(255) NOT NULL,
  "loai" VARCHAR(255) NOT NULL,
  "trangThai" VARCHAR(255) NOT NULL
);

CREATE TABLE "DonHang" (
  "id" UUID PRIMARY KEY,
  "ngayDat" TIMESTAMP WITH TIME ZONE NOT NULL,
  "diaChiNhan" VARCHAR(255) NOT NULL,
  "phuongThucNhan" VARCHAR(255) NOT NULL,
  "tongTien" DECIMAL(18,2) NOT NULL,
  "soTienGiam" DECIMAL(18,2) NOT NULL,
  "trangThaiXuLy" VARCHAR(64) NOT NULL,
  "trangThaiThanhToan" VARCHAR(64) NOT NULL,
  "daHuy" BOOLEAN NOT NULL,
  "dongGoiXong" BOOLEAN NOT NULL,
  "thoiDiemGiaoThanhCong" TIMESTAMP WITH TIME ZONE,
  "version" INTEGER NOT NULL,
  "khachHangId" UUID NOT NULL REFERENCES "TaiKhoan"("id") ON DELETE RESTRICT,
  "khuyenMaiId" UUID REFERENCES "KhuyenMai"("id") ON DELETE RESTRICT,
  "phuongThucId" UUID NOT NULL REFERENCES "PhuongThucThanhToan"("id") ON DELETE RESTRICT,
  CHECK ("tongTien" >= 0 AND "soTienGiam" >= 0),
  CHECK ("trangThaiXuLy" IN ('Chờ xác nhận','Đã xác nhận','Đang soạn hàng','Đang giao','Đã giao thành công'))
);

CREATE TABLE "ChiTietDonHang" (
  "id" UUID PRIMARY KEY,
  "maSanPhamLucMua" VARCHAR(255) NOT NULL,
  "tenSanPhamLucMua" VARCHAR(255) NOT NULL,
  "soLuong" INTEGER NOT NULL,
  "donGiaLucMua" DECIMAL(18,2) NOT NULL,
  "thanhTien" DECIMAL(18,2) NOT NULL,
  "donHangId" UUID NOT NULL REFERENCES "DonHang"("id") ON DELETE RESTRICT,
  "sanPhamId" UUID NOT NULL REFERENCES "SanPham"("id") ON DELETE RESTRICT,
  CHECK ("soLuong" > 0),
  UNIQUE ("donHangId", "sanPhamId")
);

CREATE TABLE "YeuCau" (
  "id" UUID PRIMARY KEY,
  "loai" VARCHAR(64) NOT NULL,
  "noiDung" TEXT NOT NULL,
  "thoiDiem" TIMESTAMP WITH TIME ZONE NOT NULL,
  "trangThai" VARCHAR(64) NOT NULL,
  "lyDoQuyetDinh" TEXT NOT NULL,
  "version" INTEGER NOT NULL,
  "donHangId" UUID NOT NULL REFERENCES "DonHang"("id") ON DELETE RESTRICT,
  "nguoiGuiId" UUID NOT NULL REFERENCES "TaiKhoan"("id") ON DELETE RESTRICT,
  "nguoiXuLyId" UUID REFERENCES "TaiKhoan"("id") ON DELETE RESTRICT
);

CREATE TABLE "LichSuTrangThai" (
  "id" UUID PRIMARY KEY,
  "trangThaiTruoc" VARCHAR(64) NOT NULL,
  "trangThaiSau" VARCHAR(64) NOT NULL,
  "thoiDiem" TIMESTAMP WITH TIME ZONE NOT NULL,
  "ghiChuCongKhai" TEXT NOT NULL,
  "donHangId" UUID NOT NULL REFERENCES "DonHang"("id") ON DELETE RESTRICT,
  "nguoiCapNhatId" UUID NOT NULL REFERENCES "TaiKhoan"("id") ON DELETE RESTRICT
);

CREATE TABLE "DanhGia" (
  "id" UUID PRIMARY KEY,
  "soSao" INTEGER NOT NULL,
  "noiDung" TEXT NOT NULL,
  "thoiDiem" TIMESTAMP WITH TIME ZONE NOT NULL,
  "maChongLap" UUID NOT NULL,
  "chiTietDonId" UUID NOT NULL REFERENCES "ChiTietDonHang"("id") ON DELETE RESTRICT,
  "sanPhamId" UUID NOT NULL REFERENCES "SanPham"("id") ON DELETE RESTRICT,
  "khachHangId" UUID NOT NULL REFERENCES "TaiKhoan"("id") ON DELETE RESTRICT,
  UNIQUE ("chiTietDonId"),
  UNIQUE ("maChongLap"),
  CHECK ("soSao" BETWEEN 1 AND 5),
  CHECK (char_length("noiDung") BETWEEN 1 AND 2000)
);

CREATE TABLE "PhieuSoan" (
  "id" UUID PRIMARY KEY,
  "batDau" TIMESTAMP WITH TIME ZONE NOT NULL,
  "dongGoiLuc" TIMESTAMP WITH TIME ZONE,
  "thongTinGoi" TEXT NOT NULL,
  "bangChungBanGiao" TEXT NOT NULL,
  "ghiChuChenhLech" TEXT NOT NULL,
  "donHangId" UUID NOT NULL REFERENCES "DonHang"("id") ON DELETE RESTRICT,
  "nhanVienId" UUID NOT NULL REFERENCES "TaiKhoan"("id") ON DELETE RESTRICT,
  UNIQUE ("donHangId")
);

CREATE TABLE "DongSoan" (
  "id" UUID PRIMARY KEY,
  "soLuongThucSoan" INTEGER NOT NULL,
  "ghiChu" TEXT NOT NULL,
  "phieuSoanId" UUID NOT NULL REFERENCES "PhieuSoan"("id") ON DELETE RESTRICT,
  "chiTietDonId" UUID NOT NULL REFERENCES "ChiTietDonHang"("id") ON DELETE RESTRICT,
  UNIQUE ("chiTietDonId"),
  CHECK ("soLuongThucSoan" >= 0)
);

CREATE TABLE "GiaoDichThanhToan" (
  "id" UUID PRIMARY KEY,
  "maNgoai" VARCHAR(255) NOT NULL,
  "soTien" DECIMAL(18,2) NOT NULL,
  "trangThai" VARCHAR(64) NOT NULL,
  "thoiDiem" TIMESTAMP WITH TIME ZONE NOT NULL,
  "maChongLap" UUID NOT NULL,
  "donHangId" UUID NOT NULL REFERENCES "DonHang"("id") ON DELETE RESTRICT,
  "phuongThucId" UUID NOT NULL REFERENCES "PhuongThucThanhToan"("id") ON DELETE RESTRICT,
  UNIQUE ("maChongLap"),
  CHECK ("soTien" >= 0)
);

CREATE TABLE "GioHang" (
  "id" UUID PRIMARY KEY,
  "maPhienKhach" VARCHAR(64),
  "ngayTao" TIMESTAMP WITH TIME ZONE NOT NULL,
  "chuSoHuuId" UUID REFERENCES "TaiKhoan"("id") ON DELETE RESTRICT,
  UNIQUE ("chuSoHuuId"),
  CHECK (("chuSoHuuId" IS NOT NULL) <> ("maPhienKhach" IS NOT NULL))
);

CREATE TABLE "ChiTietGioHang" (
  "id" UUID PRIMARY KEY,
  "soLuong" INTEGER NOT NULL,
  "gioHangId" UUID NOT NULL REFERENCES "GioHang"("id") ON DELETE RESTRICT,
  "sanPhamId" UUID NOT NULL REFERENCES "SanPham"("id") ON DELETE RESTRICT,
  CHECK ("soLuong" > 0),
  UNIQUE ("gioHangId", "sanPhamId")
);

CREATE TABLE "KhuyenMaiSanPham" ("khuyenMaiId" UUID NOT NULL REFERENCES "KhuyenMai"("id") ON DELETE RESTRICT, "sanPhamId" UUID NOT NULL REFERENCES "SanPham"("id") ON DELETE RESTRICT, PRIMARY KEY ("khuyenMaiId", "sanPhamId"));

CREATE INDEX "idx_don_khach_ngay" ON "DonHang" ("khachHangId", "ngayDat");

CREATE INDEX "idx_don_giao" ON "DonHang" ("trangThaiXuLy", "thoiDiemGiaoThanhCong") WHERE "daHuy" = false;

CREATE INDEX "idx_yeucau_trangthai" ON "YeuCau" ("trangThai", "thoiDiem");

CREATE INDEX "idx_lichsu_don" ON "LichSuTrangThai" ("donHangId", "thoiDiem");
COMMIT;

# Bộ báo cáo OrderOnline

Mở **BaoCao_OrderOnline.docx** để đọc/chỉnh sửa báo cáo. Bộ tài liệu hoàn thiện ở mức phân tích và thiết kế, chưa triển khai ứng dụng.

## Nội dung

- `BaoCao_OrderOnline.docx`: 4 chương, 9 đặc tả × 6 thành phần, bảng dữ liệu, hình UML/giao diện, phụ lục giả định, lỗi mô hình cũ, truy vết và 32 ca nghiệm thu đề xuất.
- `BaoCao_OrderOnline.html`: bản đọc trong trình duyệt, ảnh liên kết tương đối; giữ nguyên cây thư mục.
- `BaoCao_OrderOnline_XemNhanh.pdf`: bản xem nhanh từ HTML, nếu đã xuất; không phải bản render Microsoft Word.
- `Specs/`: 9 đặc tả Markdown chỉnh sửa được.
- `UML/UC_01` … `UML/UC_09`: Activity, DomainModel, Sequence, ClassDiagram.
- `UML/TongThe`: 4 sơ đồ tổng thể và 3 Class Diagram phân vùng bổ sung để đọc chi tiết.
- `Diagrams_Export`: 43 ảnh PNG + 43 SVG hoàn chỉnh. `PrintPanels` chứa phần hình được phân trang để chữ trong Word không quá nhỏ; vùng chồng nối đường giữa các phần.
- `Wireframes/index.html`: truy cập 9 prototype HTML. Mỗi prototype có 5 màn/trạng thái: danh sách, chi tiết, kết quả, lỗi, rỗng. Có 45 PNG; dữ liệu đều là minh họa. Không có backend.
- `Sources_Analysis`: văn bản/ảnh trích xuất từ Word, dữ liệu model/layout VPP đọc-only, bảng đối chiếu và SHA-256 nguồn.
- `Design/schema_proposal.sql`: DDL PostgreSQL đề xuất; chưa chạy PostgreSQL, còn cần service kiểm các bất biến liên bảng.
- `TRUY_VET_YEU_CAU.md`, `GIA_DINH_CAN_XAC_NHAN.md`, `KIEM_TRA_CHAT_LUONG.md`: yêu cầu, các quyết định còn mở và kết quả kiểm thực tế.
- `Build`: dữ liệu sinh mô hình, script tái tạo và bằng chứng kiểm tra.

## Việc nhóm cần làm trước khi nộp

1. Điền trường/khoa, lớp, giảng viên, tên nhóm/thành viên và MSSV ở bìa. Nguồn không có thông tin nhóm OrderOnline nên các ô được giữ `[Nhóm điền]`.
2. Xác nhận A01–A11. Đặc biệt: chính sách sửa/hủy/hoàn tiền, thiếu hàng, cách tính lượng bán, phạm vi giảm giá, đánh giá trùng và thời hạn giữ tồn. Người dùng đã đồng ý giữ đề xuất tách thanh toán/giao nhận và đánh dấu nội dung cần xác nhận, chưa chốt nghiệp vụ triển khai.
3. Mở Word, dùng Ctrl+A rồi F9 để cập nhật mục lục và số trang. Văn bản A4, các hình dài chia phần trên trang A3 ngang. Có thể chỉnh lại khổ theo quy định giảng viên sau khi kiểm chữ trong hình.
4. Kiểm bố cục bằng Word trên máy nộp. Trong môi trường đã kiểm ZIP/XML/ảnh và tạo bản PDF từ HTML; chưa có renderer Microsoft Word/LibreOffice để xác nhận phân trang DOCX cuối cùng.
5. Nếu cần nộp VPP: mở file gốc bằng Visual Paradigm, tạo bản sao rồi xuất XMI/ảnh để đối chiếu. Bộ này không ghi đè/sửa VPP native; nguồn PlantUML mới là bộ mô hình hoàn thiện độc lập.

## Tái tạo tài liệu

Thư mục kết quả nằm cạnh ba file nguồn trong checkout. Dùng checkout hiện có; không cần worktree. Không thay ba file nguồn khi tái tạo.

Cần Python 3.12 với `python-docx`, `Pillow`, `playwright`, `PyMuPDF`; Java và Graphviz cho PlantUML. PlantUML dùng bản 1.2025.10 (đã tải từ Maven Central và xác minh SHA-256). Không kèm JAR trong gói kết quả. Cung cấp đường dẫn JAR qua `PLANTUML_JAR` nếu chạy ở máy khác; script validation hiện dùng `/workspace/tools/plantuml.jar`, chỉnh đường dẫn nếu cần. Browser trong script là `/usr/bin/chromium`; chỉnh nếu chạy máy khác. Không cần internet để mở các sản phẩm đã xuất.

Chạy lần lượt từ `OrderOnline_Final/`:

```bash
python3 Build/extract_sources.py
python3 Build/models.py
python3 Build/export.py
python3 Build/wireframes.py
python3 Build/report.py
python3 Build/validate.py
python3 Build/pdf_preview.py
```

Sửa đặc tả/thuộc tính tại `Build/data.py`, hành vi Sequence/Activity tại `Build/models.py`, giao diện tại `Build/wireframes.py`, văn bản chương/bìa tại `Build/report.py`, rồi chạy lại các bước bị ảnh hưởng. Chỉnh trực tiếp DOCX/PUML/HTML vẫn được, nhưng script sinh lại sẽ thay đổi file kết quả tương ứng; giữ bản chỉnh trước khi tái tạo.

## Giới hạn kiểm chứng

Đã kiểm cú pháp UML bằng PlantUML thực, giải mã ảnh PNG/XML SVG, phương thức Sequence ↔ Class, lát cắt Domain, cấu trúc DOCX, trường/nút UI và điều hướng prototype. Xem số liệu cuối cùng trong `Build/validation.json` và `KIEM_TRA_CHAT_LUONG.md`.

Chưa chạy backend, schema PostgreSQL, giao dịch thanh toán, các ca nghiệm thu nghiệp vụ, load test, pentest hoặc usability. Không coi các kiểm tài liệu là kiểm thử hệ thống thực tế.

# Phân tích nguồn và sửa mô hình

Đọc cả hai DOCX: văn bản, bảng và ảnh nghiệp vụ. VPP: SQLite read-only, 483 model elements, 100 diagram elements; 2 sơ đồ (Use Case Diagram1, Domain Model). Đã trích xuất tất cả MODEL_ELEMENT.DEFINITION; không chạy Visual Paradigm, không giải mã đầy đủ định dạng proprietary hoặc chỉnh sửa VPP. Thumbnail VPP chỉ 180 px, không thay thế xuất native.

## F01
Nguồn: VPP association pT2eBQWGAqACHwoW: Nhân viên siêu thị – quản lý danh mục

Vấn đề: Cấp quyền quản trị danh mục cho nhân viên trái đoạn 3 nguồn.

Sửa: Chỉ Admin liên kết UC_05; AuthorizationService kiểm vai trò; không kế thừa toàn bộ quyền giữa Admin và nhân viên.

## F02
Nguồn: VPP Include P.I.BQWGAqACHwtJ và i5o.BQWGAqACHwtW; ảnh UseCase trong Word

Vấn đề: Giỏ hàng/thêm vào giỏ include Đăng nhập, trái quy tắc khách chưa đăng nhập vẫn dùng giỏ.

Sửa: Bỏ xác thực bắt buộc ở giỏ; đặt hàng include kiểm phiên/quyền, đăng nhập extend khi thiếu phiên.

## F03
Nguồn: VPP UseCase vPa6BQWGAqACHwf8 / AtW6BQWGAqACHwgW

Vấn đề: Chọn nhận hàng/thanh toán dùng Extend vào Đặt hàng, trong khi đây là bước bắt buộc của đặt hàng.

Sửa: Đặt hàng include chọn phương thức nhận và thanh toán; trực tuyến extend khi khách chọn trực tuyến. Thanh toán lại extend khi giao dịch thất bại.

## F04
Nguồn: VPP classes M6abBQWGAqACHw8Y và 9_ELBQWGAqACHwxz; tên Nhân viênh, Nhân Viên; UseCase*, Sửa hàng, Dặt hàng

Vấn đề: Tên trùng/lỗi chính tả và tên placeholder làm mất truy vết.

Sửa: Thống nhất Actor Nhân viên cửa hàng; tài khoản + vai trò biểu diễn danh tính; tách đủ 9 UC có mã. Không dùng CRUD tổng quát thay đặc tả riêng.

## F05
Nguồn: Word bảng quan hệ và VPP jgsbBQWGAqACHw7R / TEQrBQWGAqACHwzq

Vấn đề: Khách hàng có 1..* đơn/yêu cầu; composition có thể suy ra xóa tài khoản sẽ xóa lịch sử.

Sửa: Chủ sở hữu 1, số đơn/yêu cầu 0..*; Association giữ lịch sử. DonHang–ChiTietDonHang vẫn Composition vì dòng không có ý nghĩa ngoài đơn.

## F06
Nguồn: VPP XiXbBQWGAqACHw.., k_Q7BQWGAqACHw_p, lTI7BQWGAqACHw_6 và t7LbBQWGAqACHw.a

Vấn đề: Dòng–sản phẩm 1–1; sản phẩm–danh mục bị đặt 1..* ở đầu danh mục; đơn dùng nhiều phương thức hiện hành.

Sửa: Sản phẩm 1 ↔ nhiều dòng 0..*; danh mục 1 ↔ sản phẩm 0..*. Một phương thức hiện hành/đơn, nhiều lần thử GiaoDichThanhToan; A01/A05 cần xác nhận chi tiết.

## F07
Nguồn: Word ảnh Domain Model (image3.png)

Vấn đề: Admin được dùng làm lớp cha của Nhân viên, giỏ buộc 1..* dòng; đánh giá không liên kết người mua hoặc dòng mua.

Sửa: Không generalization Admin–Nhân viên; role riêng. Giỏ có 0..* dòng, chủ nullable cho khách vãng lai. DanhGia liên kết TaiKhoan + ChiTietDonHang + SanPham, có ràng buộc giao hoàn tất.

## F08
Nguồn: Word ảnh Activity (image1.png)

Vấn đề: Khâu xác thực/chuyển trạng thái và trường hợp thiếu hàng chưa đầy đủ; đường quay thanh toán thất bại không tách trục trạng thái rõ.

Sửa: 9 Activity riêng có kiểm quyền, dữ liệu, lỗi và quay lại; A01 tách xử lý/thanh toán; A03 chặn hoàn tất khi thiếu hàng.

## F09
Nguồn: Word ảnh Domain/UseCase và VPP kiểm kê 2 DIAGRAM

Vấn đề: Ảnh Word chứa Khuyến mãi/Đánh giá/Giao dịch thanh toán nhưng VPP domain lưu thiếu; chưa có 9 Sequence/Class/Activity.

Sửa: Kế thừa lớp đã có ở nguồn ảnh, bổ sung lớp thiết kế với Axx rõ ràng; không tuyên bố đã chỉnh sửa hoặc tái tạo native VPP.

Đối chiếu hình và vị trí native đầy đủ: nhóm có thể xuất ảnh/XMI từ Visual Paradigm. PlantUML mới là bộ mô hình hoàn thiện độc lập.

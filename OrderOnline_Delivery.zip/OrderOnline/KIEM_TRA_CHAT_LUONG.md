# Kiểm tra chất lượng tài liệu OrderOnline

- 72 kiểm tra đạt; 0 kiểm tra không đạt.
- 43 nguồn PlantUML đã kiểm cú pháp bằng PlantUML 1.2025.10 và xuất PNG/SVG.
- 290 lời gọi đồng bộ Sequence đã đối chiếu receiver/method ở Class chức năng và tổng thể.
- 9 đặc tả × 6 thành phần = 54 thành phần; 4 UML tổng thể + 3 bản Class phân vùng.
- 9 HTML × 5 màn/trạng thái = 45 ảnh wireframe; 27 ảnh chính chèn Word.

## Kết quả thực tế

|Kiểm tra|Kết quả|Bằng chứng|
|---|---|---|
|PlantUML syntax (actual engine)|ĐẠT|43 diagrams; exit=0;  |
|UC_01 four UML sources|ĐẠT|Activity, Domain, Sequence, Class nonempty|
|UC_01 Sequence → Class methods|ĐẠT|11 participants, 62 calls; []|
|UC_01 domain slice consistency|ĐẠT|Same associations/multiplicities; no operations|
|UC_01 shared attributes|ĐẠT|Entity attributes from same global definitions|
|UC_01 15 specification fields|ĐẠT|7 main steps, 3 alternate, 3 exception branches|
|UC_01 UI fields/buttons|ĐẠT|All specified fields/actions present in HTML|
|UC_01 five UI states|ĐẠT|List, detail, result, error, empty; navigation exercised during generation|
|UC_02 four UML sources|ĐẠT|Activity, Domain, Sequence, Class nonempty|
|UC_02 Sequence → Class methods|ĐẠT|7 participants, 22 calls; []|
|UC_02 domain slice consistency|ĐẠT|Same associations/multiplicities; no operations|
|UC_02 shared attributes|ĐẠT|Entity attributes from same global definitions|
|UC_02 15 specification fields|ĐẠT|6 main steps, 2 alternate, 3 exception branches|
|UC_02 UI fields/buttons|ĐẠT|All specified fields/actions present in HTML|
|UC_02 five UI states|ĐẠT|List, detail, result, error, empty; navigation exercised during generation|
|UC_03 four UML sources|ĐẠT|Activity, Domain, Sequence, Class nonempty|
|UC_03 Sequence → Class methods|ĐẠT|7 participants, 27 calls; []|
|UC_03 domain slice consistency|ĐẠT|Same associations/multiplicities; no operations|
|UC_03 shared attributes|ĐẠT|Entity attributes from same global definitions|
|UC_03 15 specification fields|ĐẠT|6 main steps, 3 alternate, 3 exception branches|
|UC_03 UI fields/buttons|ĐẠT|All specified fields/actions present in HTML|
|UC_03 five UI states|ĐẠT|List, detail, result, error, empty; navigation exercised during generation|
|UC_04 four UML sources|ĐẠT|Activity, Domain, Sequence, Class nonempty|
|UC_04 Sequence → Class methods|ĐẠT|6 participants, 27 calls; []|
|UC_04 domain slice consistency|ĐẠT|Same associations/multiplicities; no operations|
|UC_04 shared attributes|ĐẠT|Entity attributes from same global definitions|
|UC_04 15 specification fields|ĐẠT|6 main steps, 3 alternate, 3 exception branches|
|UC_04 UI fields/buttons|ĐẠT|All specified fields/actions present in HTML|
|UC_04 five UI states|ĐẠT|List, detail, result, error, empty; navigation exercised during generation|
|UC_05 four UML sources|ĐẠT|Activity, Domain, Sequence, Class nonempty|
|UC_05 Sequence → Class methods|ĐẠT|6 participants, 30 calls; []|
|UC_05 domain slice consistency|ĐẠT|Same associations/multiplicities; no operations|
|UC_05 shared attributes|ĐẠT|Entity attributes from same global definitions|
|UC_05 15 specification fields|ĐẠT|6 main steps, 3 alternate, 3 exception branches|
|UC_05 UI fields/buttons|ĐẠT|All specified fields/actions present in HTML|
|UC_05 five UI states|ĐẠT|List, detail, result, error, empty; navigation exercised during generation|
|UC_06 four UML sources|ĐẠT|Activity, Domain, Sequence, Class nonempty|
|UC_06 Sequence → Class methods|ĐẠT|7 participants, 27 calls; []|
|UC_06 domain slice consistency|ĐẠT|Same associations/multiplicities; no operations|
|UC_06 shared attributes|ĐẠT|Entity attributes from same global definitions|
|UC_06 15 specification fields|ĐẠT|6 main steps, 3 alternate, 3 exception branches|
|UC_06 UI fields/buttons|ĐẠT|All specified fields/actions present in HTML|
|UC_06 five UI states|ĐẠT|List, detail, result, error, empty; navigation exercised during generation|
|UC_07 four UML sources|ĐẠT|Activity, Domain, Sequence, Class nonempty|
|UC_07 Sequence → Class methods|ĐẠT|10 participants, 27 calls; []|
|UC_07 domain slice consistency|ĐẠT|Same associations/multiplicities; no operations|
|UC_07 shared attributes|ĐẠT|Entity attributes from same global definitions|
|UC_07 15 specification fields|ĐẠT|6 main steps, 3 alternate, 3 exception branches|
|UC_07 UI fields/buttons|ĐẠT|All specified fields/actions present in HTML|
|UC_07 five UI states|ĐẠT|List, detail, result, error, empty; navigation exercised during generation|
|UC_08 four UML sources|ĐẠT|Activity, Domain, Sequence, Class nonempty|
|UC_08 Sequence → Class methods|ĐẠT|9 participants, 29 calls; []|
|UC_08 domain slice consistency|ĐẠT|Same associations/multiplicities; no operations|
|UC_08 shared attributes|ĐẠT|Entity attributes from same global definitions|
|UC_08 15 specification fields|ĐẠT|6 main steps, 3 alternate, 4 exception branches|
|UC_08 UI fields/buttons|ĐẠT|All specified fields/actions present in HTML|
|UC_08 five UI states|ĐẠT|List, detail, result, error, empty; navigation exercised during generation|
|UC_09 four UML sources|ĐẠT|Activity, Domain, Sequence, Class nonempty|
|UC_09 Sequence → Class methods|ĐẠT|11 participants, 39 calls; []|
|UC_09 domain slice consistency|ĐẠT|Same associations/multiplicities; no operations|
|UC_09 shared attributes|ĐẠT|Entity attributes from same global definitions|
|UC_09 15 specification fields|ĐẠT|5 main steps, 5 alternate, 4 exception branches|
|UC_09 UI fields/buttons|ĐẠT|All specified fields/actions present in HTML|
|UC_09 five UI states|ĐẠT|List, detail, result, error, empty; navigation exercised during generation|
|PNG/SVG exports valid|ĐẠT|43 PNG + 43 SVG, verified decoding/XML|
|DOCX ZIP integrity|ĐẠT|All entries CRC checked|
|DOCX nine UCs and six parts|ĐẠT|54 substantive components|
|DOCX TOC and page numbers|ĐẠT|TOC field + static contents; PAGE footer; TOC must be updated in Word|
|DOCX embedded images|ĐẠT|139 images including print panels; all decode|
|No BookStore domain copied|ĐẠT|BookStore only referenced as excluded template domain|
|Original inputs unchanged|ĐẠT|Both DOCX + VPP exact SHA-256 match|
|No Admin state change UC|ĐẠT|Admin associated only UC_02–UC_06|

## Giới hạn và việc nhóm cần làm

- Chưa triển khai backend/PostgreSQL hoặc tích hợp thanh toán; 32 ca nghiệp vụ trong báo cáo là đề xuất, chưa chạy. Không có số liệu tải, pentest hoặc usability test.
- VPP đọc ở mức SQLite/model definition và đối chiếu ảnh Word; không chạy renderer Visual Paradigm, không chỉnh file gốc. XMI/native layout chưa xác minh.
- DOCX kiểm cấu trúc/XML/ảnh và nội dung; chưa mở bằng Microsoft Word/LibreOffice. Mục lục tự động và số trang phụ thuộc renderer Word; cập nhật Ctrl+A, F9 khi mở.
- UML dài được chia hình có vùng chồng trong Word; bản PNG/SVG đầy đủ giữ nguyên để xem đường và phóng to.
- Thông tin bìa đang để [Nhóm điền] vì nguồn không có danh tính nhóm OrderOnline.
- A01–A11 là đề xuất cần xác nhận, đặc biệt hủy/hoàn tiền, thiếu hàng, thống kê và khuyến mãi. Người dùng đồng ý giữ đề xuất, chưa chốt chính sách triển khai.
- Prototype chỉ mô phỏng UI, dùng dữ liệu minh họa; chưa xác thực hay ghi dữ liệu thật.

## Bản PDF xem nhanh

- Đã xuất 167 trang bằng Chromium từ HTML; trích xuất được văn bản và tìm thấy đủ tiêu đề 9 UC, phụ lục A.
- Đã xem trực quan các trang mẫu 2, 31, 51 và 84 của bản cuối; kiểm các bảng/trang UML/giao diện đại diện. Các hình dài có phần tiếp nối, bản PNG/SVG đầy đủ dùng để phóng to.
- Đây không phải kết quả kiểm phân trang DOCX bằng Word.

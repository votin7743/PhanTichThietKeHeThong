# Truy vết yêu cầu

|UC|Chức năng|BR / giả định|Đặc tả|UML|UI|
|---|---|---|---|---|---|
|UC_01|Soạn hàng và đóng gói|BR02, BR06, BR07; A03, A09–A11|Specs/UC_01.md|UML/UC_01/{Activity,DomainModel,Sequence,ClassDiagram}.puml|Wireframes/UC_01/prototype.html|
|UC_02|Thống kê sản phẩm bán được|BR02, BR09; A04, A09|Specs/UC_02.md|UML/UC_02/{Activity,DomainModel,Sequence,ClassDiagram}.puml|Wireframes/UC_02/prototype.html|
|UC_03|Quản lý chương trình giảm giá|BR02, BR04, BR09; A05, A09|Specs/UC_03.md|UML/UC_03/{Activity,DomainModel,Sequence,ClassDiagram}.puml|Wireframes/UC_03/prototype.html|
|UC_04|Quản lý người dùng|BR02, BR09; A06, A09|Specs/UC_04.md|UML/UC_04/{Activity,DomainModel,Sequence,ClassDiagram}.puml|Wireframes/UC_04/prototype.html|
|UC_05|Quản lý danh mục sản phẩm|BR02, BR09; A07, A09|Specs/UC_05.md|UML/UC_05/{Activity,DomainModel,Sequence,ClassDiagram}.puml|Wireframes/UC_05/prototype.html|
|UC_06|Quản lý thông tin sản phẩm|BR02, BR09, BR10; A07, A09, A10|Specs/UC_06.md|UML/UC_06/{Activity,DomainModel,Sequence,ClassDiagram}.puml|Wireframes/UC_06/prototype.html|
|UC_07|Theo dõi tình trạng đơn hàng|BR02, BR06, BR08; A01, A09|Specs/UC_07.md|UML/UC_07/{Activity,DomainModel,Sequence,ClassDiagram}.puml|Wireframes/UC_07/prototype.html|
|UC_08|Đánh giá sản phẩm|BR02, BR08; A08, A09|Specs/UC_08.md|UML/UC_08/{Activity,DomainModel,Sequence,ClassDiagram}.puml|Wireframes/UC_08/prototype.html|
|UC_09|Xem và xử lý đơn hàng|BR02, BR06, BR07, BR09; A01, A02, A09, A11|Specs/UC_09.md|UML/UC_09/{Activity,DomainModel,Sequence,ClassDiagram}.puml|Wireframes/UC_09/prototype.html|

## Kiểm thử nghiệp vụ đề xuất (chưa chạy backend)

- T01 – UC_01: Đơn đã xác nhận, đủ hàng, đóng gói và bàn giao đủ bằng chứng → Ghi từng mốc; Đang giao chỉ sau bàn giao; một lần cập nhật kho.
- T02 – UC_01: Thiếu một dòng khi đối chiếu → Ghi chênh lệch, chặn đóng gói/bàn giao; giữ Đang soạn hàng.
- T03 – UC_01: Đơn đổi version giữa soạn và bàn giao → Rollback ghi mới, báo tải lại; không ghi giao sai.
- T04 – UC_02: Hai đơn đã giao lượng 2 và 3 cùng sản phẩm; một đơn chờ lượng 7 → Tổng 5, không đếm đơn chờ; chi tiết đối chiếu đủ hai đơn.
- T05 – UC_02: Ngày kết thúc trước ngày bắt đầu → Lỗi trường ngày; không chạy/hiển thị báo cáo thành công.
- T06 – UC_02: Không có đơn trong kỳ → Bảng rỗng, tổng 0; khác với lỗi truy vấn.
- T07 – UC_03: Mã giảm trùng hoặc phần trăm 110 → Từ chối; giữ bản nháp để sửa.
- T08 – UC_03: Ngừng áp dụng chương trình đã dùng cho đơn cũ → Không mất liên kết hay thay tổng đơn cũ.
- T09 – UC hỗ trợ: Đặt đơn với hai chương trình giảm giá → Từ chối áp dụng hai; chỉ tối đa một.
- T10 – UC_04: Admin sửa vai trò khách thành nhân viên theo A06 → Lưu vai trò, dấu vết và thu hồi phiên cần thiết.
- T11 – UC_04: Khóa/hạ quyền Admin cuối cùng hoặc email trùng → Từ chối theo A06, không mất tài khoản quản trị.
- T12 – UC_04: Nhân viên gọi API quản trị người dùng → Từ chối phía server, không lộ thông tin.
- T13 – UC_05: Xóa danh mục có sản phẩm → Từ chối, gợi ý ngừng dùng, không sản phẩm mồ côi.
- T14 – UC_05: Danh mục không có tham chiếu, Admin xác nhận xóa → Xóa có điều kiện; kiểm lại FK khi commit.
- T15 – UC_05: Có sản phẩm được thêm đồng thời khi xóa → Một giao dịch bị từ chối/xung đột; không đứt FK.
- T16 – UC_06: Giá âm hoặc tồn nhỏ hơn lượng giữ chỗ → Từ chối cập nhật; lỗi rõ ở trường.
- T17 – UC_06: Đổi tên/giá sản phẩm sau khi có đơn → Chi tiết đơn cũ giữ snapshot giá/tên.
- T18 – UC_06: Ngừng kinh doanh sản phẩm có lịch sử → Giữ sản phẩm và lịch sử, không tự hủy đơn.
- T19 – UC_07: Khách A đoán mã đơn khách B → Không tìm thấy đơn khả dụng; không dữ liệu đơn B.
- T20 – UC_07: Đơn cũ không có lịch sử → Hiển thị trạng thái hiện tại, không dựng timestamp giả.
- T21 – UC_07: Lọc danh sách hoặc làm mới chi tiết → Điều kiện sở hữu luôn còn trong query.
- T22 – UC_08: Khách mua dòng thuộc đơn đã giao, sao/nội dung đúng → Lưu đánh giá đúng người/sản phẩm/dòng.
- T23 – UC_08: Chưa mua hoặc chưa giao → Từ chối, không tạo đánh giá.
- T24 – UC_08: Sao 0/6, nội dung rỗng hoặc gửi lặp → Lỗi dữ liệu; gửi lặp không tạo bản ghi thứ hai.
- T25 – UC_09: Nhân viên xác nhận đơn chờ đủ thông tin → Đã xác nhận + lịch sử nguyên tử, chưa tự soạn.
- T26 – UC_09: Yêu cầu sửa/hủy khi đang soạn/đang giao → Từ chối có lý do; không thay đơn.
- T27 – UC_09: Sửa/hủy đơn đã thanh toán chưa có chính sách hoàn tiền → Chờ xác minh, không tự hoàn tiền hoặc hủy.
- T28 – UC_09: Admin gọi lệnh cập nhật đơn hoặc nhảy trạng thái → Từ chối, trạng thái không đổi.
- T29 – UC_09: Yêu cầu đã được xử lý hoặc version cũ → Không áp dụng lần hai; trả kết quả cũ/tải lại.
- T30 – UC hỗ trợ: Đặt số lượng vượt tồn khả dụng → Chặn, yêu cầu chỉnh giỏ; không tạo đơn thành công.
- T31 – UC hỗ trợ: Thanh toán thất bại/timeout rồi thử lại → Không ghi thành công giả; xác minh giao dịch/mã chống lặp.
- T32 – UC hỗ trợ: Callback giả hoặc lặp của nhà cung cấp → Từ chối giả, lặp không ghi thêm tác động tài chính.

# Các đề xuất cần nhóm xác nhận

Người dùng đã đồng ý giữ đề xuất tách thanh toán/giao nhận và ghi rõ chính sách còn thiếu; chưa chốt quy tắc cuối cùng.

## A01 – Tách hai trục trạng thái

Nguồn văn bản gọi Đã thanh toán là trạng thái đơn nhưng cũng liệt kê chuỗi giao nhận. Đề xuất DonHang.trangThaiXuLy giữ 5 trạng thái nguồn; GiaoDichThanhToan.trangThai và DonHang.trangThaiThanhToan biểu diễn kết quả thanh toán riêng. Không suy diễn thanh toán thành công thành đã giao.

## A02 – Sửa/hủy và hoàn tiền

Nguồn vừa nói chưa xuất kho thì chấp nhận, vừa cho phép từ chối khi đã soạn. Đề xuất mặc định chỉ chấp nhận ở Chờ xác nhận/Đã xác nhận; từ Đang soạn hàng trở đi từ chối. Hủy lưu kết quả yêu cầu và cờ daHuy, không thêm trạng thái chính thức vào chuỗi giao nhận. Hoàn tiền, thời điểm giải phóng hàng giữ chỗ và sửa đơn đã thanh toán chưa được quy định; các ca này chuyển chờ xác minh, không tự động sửa/hủy hoặc hoàn tiền.

## A03 – Thiếu hàng khi soạn

Ghi nhận chênh lệch; không xác nhận đóng gói, không bàn giao và không tự thay sản phẩm. Giữ Đang soạn hàng, chờ xác minh với người phụ trách. Cách bổ sung hàng, giao một phần hoặc hủy cần nhóm xác nhận.

## A04 – Công thức thống kê

Đề xuất chỉ đếm chi tiết đơn có trangThaiXuLy = Đã giao thành công và daHuy = false; lọc theo thoiDiemGiaoThanhCong trong khoảng [từ ngày 00:00, ngày sau đến ngày 00:00), giờ Asia/Ho_Chi_Minh. Chưa xử lý trả hàng vì nguồn không mô tả. Không dùng giá hiện tại để tính doanh thu lịch sử.

## A05 – Khuyến mãi

Đề xuất mã duy nhất, tên, kiểu PHAN_TRAM/SO_TIEN, giá trị, ngày bắt đầu/kết thúc, trạng thái và tập sản phẩm áp dụng; giảm phần trăm 0 < giá trị <= 100, số tiền > 0, không làm tổng tiền âm. Phạm vi áp dụng toàn đơn/từng sản phẩm, điều kiện tối thiểu và phân bổ giảm giá cần xác nhận trước triển khai thanh toán.

## A06 – Tài khoản và vai trò

Đề xuất mỗi tài khoản có đúng một vai trò Khách hàng/Nhân viên cửa hàng/Admin; khóa thay vì xóa lịch sử; không tự khóa hoặc hạ quyền Admin cuối cùng. Danh tính dùng email duy nhất; không công khai mật khẩu hoặc hash. Cơ chế tạo tài khoản Admin, thay đổi quyền và lưu dấu vết cần được tổ chức phê duyệt.

## A07 – Danh mục và sản phẩm

Kế thừa một sản phẩm thuộc một danh mục. Đề xuất danh mục có thể rỗng; chỉ xóa danh mục chưa có sản phẩm và tham chiếu, còn lại ngừng sử dụng. Giá >= 0 và tồn kho là số nguyên >= 0. Điều chỉnh tồn kho phải ghi dấu vết; không suy diễn đây là hệ thống quản lý nhập kho đầy đủ.

## A08 – Đánh giá

Đề xuất thang sao nguyên 1–5, nội dung 1–2000 ký tự, một đánh giá/chi tiết đơn hàng; chặn gửi trùng bằng ràng buộc duy nhất. Cho phép nhiều lần mua tạo đánh giá khác nhau; chính sách sửa/xóa/kiểm duyệt chưa được xác định, không cấp quyền tự động.

## A09 – Lưu vết và đồng thời

Đề xuất lịch sử trạng thái, phiên bản khóa lạc quan, giao dịch nguyên tử và mã chống lặp cho thao tác ghi. Đây là cơ chế thiết kế bảo toàn dữ liệu, không phải yêu cầu đã được kiểm thử. Phiên bản thay đổi khi soạn/đóng gói/yêu cầu, không chỉ khi chuyển trạng thái.

## A10 – Tồn kho và lưu lịch sử

Đề xuất phân biệt lượng vật lý, lượng giữ chỗ và lượng khả dụng; giữ chỗ nguyên tử khi đặt hàng, giảm vật lý lúc bàn giao, chuyển lượng giữ chỗ tương ứng. Đơn đã tạo lưu mã/tên/đơn giá tại thời điểm mua. Đây là thiết kế đề xuất; thời hạn giữ chỗ, hủy và thanh toán lại cần xác nhận.

## A11 – Giao nhận

Đề xuất đóng gói là dấu mốc dongGoiXong, không tạo trạng thái Đã đóng gói. Bàn giao do UC_01 ghi Đang giao; UC_09 chỉ ghi Đã giao thành công khi có bằng chứng nhận hàng. Đơn vị vận chuyển không là Actor tự động vì nguồn chưa quy định API tích hợp.

